const contactRouter = require("express").Router();

module.exports = contactRouter;